from pathlib import Path
import sys, json, hashlib, importlib.util, math, traceback, datetime
import numpy as np
import mpmath as mp
from scipy.integrate import quad
D=Path(__file__).resolve().parent
MODE='optimized' if sys.flags.optimize else 'normal'
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
C=load('review_candidate',D/'_gapn2_second_variation_probe.py')
OLD=load('review_predecessor',D/'predecessor.py')
ROWS=[]
def require(ok,msg):
    if not ok: raise RuntimeError(msg)
def reject(f):
    try: f()
    except ValueError as e: return str(e)
    raise RuntimeError('expected rejection, got acceptance')
def group(name,f):
    try: row={'name':name,'passed':True,'evidence':f()}
    except Exception: row={'name':name,'passed':False,'traceback':traceback.format_exc()}
    ROWS.append(row); print(json.dumps(row),flush=True)
    (D/('checks-'+MODE+'.json')).write_text(json.dumps({'mode':MODE,'candidate_sha256':hashlib.sha256((D/'_gapn2_second_variation_probe.py').read_bytes()).hexdigest(),'rows':ROWS},indent=2))
def provenance():
    names=['review_candidate','_gapn2_symmetry_recon','_gapn2_jacobian_probe','_gapn2_jacobian_analytic']
    out={}
    for name in names:
        p=Path(sys.modules[name].__file__).resolve(); require(p.parent==D,'import escaped supplied copies')
        out[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    return out

def bump_resolution():
    data=json.loads((D.parent/'normal/n2R4SUP.json').read_text())
    blocks=data['blocks']; centers=np.asarray(data['edges'][1:-1]); c=centers[0]
    out=[]
    for eta in [1e-20,1e-16]:
        x,w,k=OLD.quadrature_rule(blocks,64,np.r_[centers-eta,centers+eta])
        masses=[float(w@(np.abs(x-a)<eta)/(2*eta)) for a in centers]
        out.append({'kind':'predecessor_loss','eta':eta,'masses':masses,'first_endpoints':[c-eta,c,c+eta],'current_error':reject(lambda:C.checked_bump_breaks(blocks,centers,eta,64))})
    # Distinct density endpoints but no representable interior nodes.
    left=.49; gap=np.nextafter(left,np.inf)-left
    tiny=((left,1.),(gap,2.),(1-left-gap,1.))
    out.append({'kind':'distinct_endpoint_no_nodes','gap':gap,'error':reject(lambda:C.checked_bump_breaks(tiny,[.5],.01,64))})
    # At adequate support width, increasing order can make another short interval unresolved.
    gap=16384*np.spacing(left); small=((left,1.),(gap,2.),(1-left-gap,1.))
    C.checked_bump_breaks(small,[.5],.01,64)
    out.append({'kind':'high_order_actual_nodes','gap':gap,'order64':'accepted','order512':reject(lambda:C.checked_bump_breaks(small,[.5],.01,512))})
    for label,bb,cc,eta,order in [
        ('default-high-order',blocks,centers,5e-4,512),
        ('overlapping',((1.,1.),),np.array([.4,.5]),.1,128),
        ('touching',((1.,1.),),np.array([.375,.625]),.125,64),
        ('duplicate-centers',((1.,1.),),np.array([.5,.5]),.125,64),
        ('resolved-narrow',((1.,1.),),np.array([.5]),1e-7,64)]:
        breaks=C.checked_bump_breaks(bb,cc,eta,order);x,w,knots=C.quadrature_rule(bb,order,breaks)
        masses=[float(w@(np.abs(x-a)<eta)/(2*eta)) for a in cc]
        require(max(abs(m-1) for m in masses)<1e-8,'accepted support lost mass')
        out.append({'kind':label,'eta':eta,'order':order,'masses':masses})
    threshold=(2**20)*np.spacing(.5)
    out.append({'kind':'spacing-policy-boundary','threshold':threshold,'below':reject(lambda:C.checked_bump_breaks(((1.,1.),),[.5],np.nextafter(threshold,0),64)),'at':len(C.checked_bump_breaks(((1.,1.),),[.5],threshold,64))})
    return out

def default_masses():
    out=[]
    for name in ['n2R4SUP','n3R4SUP','n2R10SUP','n2R4INF']:
        r=json.loads((D.parent/'normal'/(name+'.json')).read_text());b=r['blocks'];a=np.array(r['edges'][1:-1]);eta=r['P3'][0]['half_width']
        x,w,_=C.quadrature_rule(b,64,C.checked_bump_breaks(b,a,eta,64))
        unit=(abs(x[None,:]-a[:,None])<eta)/(2*eta);m=unit@w
        require(max(abs(m-1))<3e-12,'default bump is not unit mass')
        directions=[]
        for row in r['P3']:
            q=-np.diff(np.array(b)[:,1])*np.array(row['displacement']);h=q@unit
            require(np.max(abs(h))>0,'nonzero requested direction was lost')
            measured=float(w@h);exact=float(np.sum(q))
            require(abs(measured-exact)<3e-12*max(1.,float(sum(abs(q)))),'default signed mass lost')
            directions.append({'max_abs_sample':float(max(abs(h))),'integral':measured,'requested_integral':exact})
        out.append({'case':name,'unit_masses':m.tolist(),'directions':directions})
    return out

def projections():
    rng=np.random.default_rng(7654321);errors=[]
    with mp.workdps(100):
        for metric in ['euclidean','width-weighted']:
            for scale in [1.,1e-250,1e250,np.nextafter(0.,1.)]:
                for _ in range(4):
                    a=np.array([2.,-3.,5.])*scale;b=rng.normal(size=3);w=np.array([.02,.28,.7])
                    got=C.project_tangent(b,a,w,metric)
                    aa=list(map(mp.mpf,a));bb=list(map(mp.mpf,b));ww=list(map(mp.mpf,w))
                    v=aa if metric=='euclidean' else [x/y for x,y in zip(aa,ww)]
                    alpha=mp.fsum(x*y for x,y in zip(bb,aa))/mp.fsum(x*y for x,y in zip(v,aa))
                    expected=[x-alpha*y for x,y in zip(bb,v)]
                    err=max(abs(mp.mpf(x)-y) for x,y in zip(got,expected))/max(1,max(abs(x) for x in expected))
                    errors.append(float(err));require(err<mp.mpf('5e-16'),'projection differs from independent exact formula')
        b=np.array([1.,-2.]);z=C.project_tangent(b,[0.,0.]);require(np.array_equal(z,b) and not np.shares_memory(z,b),'zero normal not independent identity copy')
    # Validate that the width-weighted CLI generated the requested projections.
    r=json.loads((D.parent/'normal/weighted.json').read_text());aa=np.array(list(map(float,r['block_integrals_mp'])));w=np.array(r['blocks'])[:,0];rng=np.random.default_rng(20260813);maxerr=0.
    for g in ['P1','P2']:
        for row in r[g]:
            b=rng.normal(size=len(w));expect=b-(b@aa)/(aa@(aa/w))*(aa/w)
            if g=='P1':expect*=.01/max(abs(expect))
            maxerr=max(maxerr,float(max(abs(expect-np.array(row['coefficients'])))))
    require(maxerr<1e-14,'weighted CLI did not apply metric')
    return {'independent_mp_cases':len(errors),'max_normwise_error':max(errors),'weighted_cli_max_coefficient_error':maxerr}

# Independent block-local transfer amplitudes, using adaptive integration for mass.
def local_modes(blocks,roots):
    count=len(roots);seg=[];u=np.zeros(count);up=np.ones(count);mass=np.zeros(count)
    for length,rho in blocks:
        freq=roots*np.sqrt(rho);a=u.copy();b=up/freq
        seg.append((freq,a,b))
        for k in range(count):
            mass[k]+=rho*quad(lambda t:(a[k]*np.cos(freq[k]*t)+b[k]*np.sin(freq[k]*t))**2,0,length,epsabs=2e-14,epsrel=2e-13)[0]
        u=a*np.cos(freq*length)+b*np.sin(freq*length);up=freq*(-a*np.sin(freq*length)+b*np.cos(freq*length))
    return [(f,a/np.sqrt(mass),b/np.sqrt(mass)) for f,a,b in seg],u

def integrals(seg,k,lo,hi):
    # Integral of Re(z_k exp(i*w_k*t))*Re(z_l exp(i*w_l*t)).
    f,a,b=seg;z=a-1j*b;length=hi-lo;mid=(lo+hi)/2
    def E(freq):return length*np.exp(1j*freq*mid)*np.sinc(freq*length/(2*np.pi))
    return .5*np.real(z[k]*np.conjugate(z)*E(f[k]-f)+z[k]*z*E(f[k]+f))

def normalization_and_pairings():
    r=json.loads((D.parent/'normal/n2R4SUP.json').read_text());blocks=r['blocks'];p=C.SpectralProbe(blocks,21,64);segs,boundary=local_modes(blocks,p.roots)
    a=np.array(r['P2'][0]['coefficients']);_,cu,cw,diag=p.pairings(C.block_direction(a,p.edges));ref=np.zeros_like(cu);gram=np.zeros_like(cu)
    for i,(length,rho) in enumerate(blocks):
        for k in range(len(p.roots)):
            v=integrals(segs[i],k,0,length);ref[k]+=a[i]*v;gram[k]+=rho*v
    require(np.max(abs(ref-cu))<2e-13,'unweighted pairings differ')
    require(np.max(abs(gram-np.eye(len(gram))))<3e-13,'weighted normalization/orthogonality failure')
    require(np.max(abs(ref-cw))>.1,'weighted and unweighted negative control absent')
    fh=float(p.lam[1]*ref[1,1]-p.lam[2]*ref[2,2]);reported=float(r['P2'][0]['direct_fh']);require(abs(fh-reported)<1e-12,'independent tangency failure')
    q=C.q_formula(p.lam,cu,cw,2,diag);q_unused=C.q_formula(p.lam,cu,123*np.eye(21),2,diag);require(q==q_unused,'Q incorrectly depends on weighted pairings')
    return {'weighted_gram_max_error':float(np.max(abs(gram-np.eye(len(gram))))),'unweighted_pairing_max_error':float(np.max(abs(ref-cu))),'weighted_negative_control_difference':float(np.max(abs(ref-cw))),'direct_fh_independent':fh,'direct_fh_reported':reported,'max_boundary_value':float(max(abs(boundary))),'Cw_independence':q==q_unused}

def constant_case_and_fd():
    r=json.loads((D.parent/'normal/R1.json').read_text());require(abs(r['lambda_n']-4*np.pi**2)<1e-12 and abs(r['lambda_np1']-9*np.pi**2)<1e-12,'R=1 eigenvalues incorrect')
    keys=['Q_interface_hessian_fd','Q_linear_fixed_bump','half_interface_acceleration','finite_comparison_difference'];require(all(row[k]==0 for row in r['P3'] for k in keys),'R=1 zero jumps did not remove P3')
    blocks=[(.25,1.),(.75,1.)];p=C.SpectralProbe(blocks,21,64);coeff=np.array([.7,-.4]);_,cu,cw,diag=p.pairings(C.block_direction(coeff,p.edges))
    with mp.workdps(70):
        expected=[]
        for k in range(1,22):
            row=[]
            for l in range(1,22):
                def primitive(x):
                    if k==l:return x-mp.sin(2*k*mp.pi*x)/(2*k*mp.pi)
                    return mp.sin((k-l)*mp.pi*x)/((k-l)*mp.pi)-mp.sin((k+l)*mp.pi*x)/((k+l)*mp.pi)
                row.append(mp.mpf(float(coeff[0]))*(primitive(mp.mpf('.25'))-primitive(0))+mp.mpf(float(coeff[1]))*(primitive(1)-primitive(mp.mpf('.25'))))
            expected.append(row)
        lam=[k*k*mp.pi**2 for k in range(1,22)]
        e2=[2*lam[k]*expected[k][k]**2+2*lam[k]**2*mp.fsum(expected[k][l]**2/(lam[k]-lam[l]) for l in range(21) if l!=k) for k in [0,1]]
        qref=(e2[1]-e2[0])/2;qgot=C.q_formula(p.lam,cu,cw,1,diag)
        require(abs(qref-qgot)<mp.mpf('2e-12'),'Fourier finite-sum Q mismatch')
        errors=[]
        for step in [.01,.3,.9]:
            fd=C.fd_gap(blocks,[1.,1.],1,step,70);exact=3*mp.pi**2/(1-mp.mpf(step)**2)
            errors.append(float(abs(fd-exact)));require(abs(fd-exact)<mp.mpf('1e-11'),'positive finite-step scaling mismatch')
        rejected=[reject(lambda step=step:C.fd_gap(blocks,[1.,1.],1,step,60)) for step in [1.,1.1]]
    return {'R1_P3_zero':True,'R1_eigenvalues':[r['lambda_n'],r['lambda_np1']],'R1_nonzero_P1_Q':[row['Q'] for row in r['P1']],'fourier_Q':float(qref),'candidate_Q':qgot,'pairing_max_error':float(np.max(abs(cu-np.array(expected,dtype=float)))),'positive_finite_step_errors':errors,'nonpositive_endpoint_rejections':rejected}

def p3_independent():
    r=json.loads((D.parent/'normal/n2R4SUP.json').read_text());blocks=r['blocks'];n=2; p=C.SpectralProbe(blocks,61,64);segs,_=local_modes(blocks,p.roots);edges=np.array(r['edges']);centers=edges[1:-1];jumps=np.diff(np.array(blocks)[:,1]);eta=r['P3'][0]['half_width']
    bpair=np.zeros((len(centers),2,61));fp=[]
    for j,c in enumerate(centers):
        for i in range(len(blocks)):
            lo=max(c-eta,edges[i]);hi=min(c+eta,edges[i+1])
            if hi>lo:
                for kk,k in enumerate([1,2]):bpair[j,kk]+=integrals(segs[i],k,lo-edges[i],hi-edges[i])/(2*eta)
        f,a,b=segs[j];t=blocks[j][0];u=a*np.cos(f*t)+b*np.sin(f*t);up=f*(-a*np.sin(f*t)+b*np.cos(f*t));fp.append(2*(p.lam[1]*u[1]*up[1]-p.lam[2]*u[2]*up[2]))
    rows=[]
    for row in r['P3']:
        d=np.array(row['displacement']);B=np.tensordot(-jumps*d,bpair,axes=(0,0));terms=[]
        for kk,k in enumerate([1,2]):
            other=np.arange(61)!=k
            terms.append(p.lam[k]*B[kk,k]**2+p.lam[k]**2*np.sum(B[kk,other]**2/(p.lam[k]-p.lam[other])))
        q=terms[1]-terms[0];accel=-.5*sum(jumps*d*d*np.array(fp))
        require(abs(q-row['Q_linear_fixed_bump'])<2e-10,'P3 independent pairings/Q mismatch')
        require(abs(accel-row['half_interface_acceleration'])<1e-9,'negative half-interface acceleration mismatch')
        rows.append({'Q_linear_independent':q,'Q_error':q-row['Q_linear_fixed_bump'],'half_acceleration_independent':float(accel),'acceleration_error':float(accel-row['half_interface_acceleration'])})
    # Separately take a finite difference along moved interfaces at high precision.
    shape=[]
    with mp.workdps(70):
        disp=[mp.mpf(float(x)) for x in r['P3'][0]['displacement']];dl=[disp[0]]+[disp[i]-disp[i-1] for i in range(1,len(disp))]+[-disp[-1]]
        def gap(t):
            lens=[mp.mpf(float(L))+t*d for (L,_),d in zip(blocks,dl)];require(min(lens)>0,'shape path collided')
            def shoot(root):
                u=mp.mpf(0);v=mp.mpf(1)
                for L,(_,rho) in zip(lens,blocks):
                    w=root*mp.sqrt(rho);cs=mp.cos(w*L);sn=mp.sin(w*L);u,v=u*cs+v*sn/w,-u*w*sn+v*cs
                return u
            rr=[mp.findroot(shoot,mp.mpf(float(p.roots[k])))*1 for k in [1,2]]
            return rr[1]**2-rr[0]**2
        g0=gap(mp.mpf(0))
        for h in ['1e-4','1e-5','1e-6']:
            t=mp.mpf(h);half=(gap(t)-2*g0+gap(-t))/(2*t*t);shape.append({'h':h,'half_second':float(half),'minus_reported_edge':float(half-r['P3'][0]['Q_interface_hessian_fd'])})
        require(abs(shape[-1]['minus_reported_edge'])<2e-5,'edge Hessian disagrees with finite shape path')
    return {'fixed_width':eta,'finite_modes':61,'rows':rows,'shape_fd':shape,'reported_finite_comparison_differences':[row['finite_comparison_difference'] for row in r['P3']]}

for name,fn in [('provenance',provenance),('bump_resolution',bump_resolution),('default_bump_masses',default_masses),('independent_projection',projections),('normalization_pairings_tangency',normalization_and_pairings),('constant_case_finite_step',constant_case_and_fd),('P3_independent_fixed_width',p3_independent)]:group(name,fn)
raise SystemExit(int(any(not row['passed'] for row in ROWS)))
