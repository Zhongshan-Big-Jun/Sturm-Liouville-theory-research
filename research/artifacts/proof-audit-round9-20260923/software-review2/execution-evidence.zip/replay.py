from pathlib import Path
import sys, json, subprocess, datetime, hashlib, os
ROOT=Path(__file__).resolve().parent
PACKET=Path('/mnt/f/LaTeX/BVE research/research/artifacts/proof-audit-round9-20260923/software-review2/research/library/reviews/packets/e8853bf3b24cb634e2bec6d557e3f6c7bbe374d50d7ac9a5101aea00a8a2381f')
GROUP=sys.argv[1]; D=ROOT/GROUP
PY=[sys.executable,'-B']+(['-O'] if GROUP=='optimized' else [])
ROWS=[]
def run(label,args):
    argv=PY+args; start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (D/(label+'.stdout.log')).open('wb') as out,(D/(label+'.stderr.log')).open('wb') as err:
        p=subprocess.run(argv,cwd=D,stdout=out,stderr=err,timeout=240)
    row={'label':label,'argv':argv,'cwd':str(D),'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'stdout':str(D/(label+'.stdout.log')),'stderr':str(D/(label+'.stderr.log'))}
    ROWS.append(row);(D/'execution.json').write_text(json.dumps(ROWS,indent=2))
    print(json.dumps(row),flush=True)
    return row
if GROUP in ['normal','optimized']:
    run('regressions',[str(D/'test_candidate.py'),'--output',str(D/'regressions.json')])
    run('resolution-regressions',[str(D/'test_f1.py')])
    run('projection-regression',[str(D/'regression_projection.py'),str(D/'_gapn2_second_variation_probe.py')])
if GROUP=='normal':
    cases=[('n2R4SUP',2,4,'sup',[]),('n3R4SUP',3,4,'sup',[]),('n2R10SUP',2,10,'sup',[]),('n2R4INF',2,4,'inf',[]),('R1',2,1,'sup',[]),('weighted',2,4,'sup',['--metric','width-weighted'])]
    for label,n,r,mode,extras in cases:
        row=run(label,[str(D/'_gapn2_second_variation_probe.py'),str(n),str(r),mode]+extras+['--output',str(D/(label+'.json'))])
        if row['exit_code']==0:
            data=json.loads((D/(label+'.json')).read_text())
            identities={Path(path).name:{'recorded':h,'actual':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'within_copy':Path(path).parent==D} for path,h in data['source_sha256'].items()}
            row['import_identities']=identities
            if label.startswith('n'):
                expected=json.loads((PACKET/'inputs/inputs/candidate'/(label+'.json')).read_text())
                data.pop('source_sha256');expected.pop('source_sha256')
                row['numeric_payload_exact']=data==expected
                row['log_exact']=(D/(label+'.stdout.log')).read_bytes()==(PACKET/'inputs/inputs/candidate'/(label+'.log')).read_bytes()
                row['stderr_exact']=(D/(label+'.stderr.log')).read_bytes()==(PACKET/'inputs/inputs/candidate'/(label+'.stderr.log')).read_bytes()
                print(json.dumps({k:row[k] for k in ['label','numeric_payload_exact','log_exact','stderr_exact']}),flush=True)
            (D/'execution.json').write_text(json.dumps(ROWS,indent=2))
if GROUP=='sensitivity':
    run('sensitivity',[str(D/'sensitivity.py')])
