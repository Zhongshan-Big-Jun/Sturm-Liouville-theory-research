import ast
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import traceback

import mpmath as mp
import numpy as np
from scipy.integrate import quad

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'run'
sys.path.insert(0, str(RUN / 'scripts'))
import _gapn2_second_variation_probe as C

ROWS = []
def need(value, message):
    if not value:
        raise RuntimeError(message)

def group(name, fn):
    try:
        row = {'name': name, 'passed': True, 'evidence': fn()}
    except Exception:
        row = {'name': name, 'passed': False, 'traceback': traceback.format_exc()}
    ROWS.append(row)
    print(json.dumps(row, indent=2), flush=True)

def projection_reference():
    rng = np.random.default_rng(912034)
    cases = []
    for m in (1, 2, 9, 30):
        for _ in range(8):
            b = rng.normal(size=m)
            a = rng.normal(size=m) * 10.**rng.uniform(-300, 300)
            w = 10.**rng.uniform(-300, 300, size=m)
            cases.append((b,a,w))
    tiny=np.nextafter(0.,1.)
    cases.extend([
        (np.array([1.,2.]), np.array([tiny,0.]), np.array([tiny,1e308])),
        (np.array([1e308,1e308]), np.array([1.,1.]), np.array([1.,1.])),
        (np.array([1.7,-.6,.2]), np.array([2e-300,-3e-300,5e-300]), np.array([1e-300,1.,1e300])),
        (np.array([1.7,-.6,.2]), np.array([2e300,-3e300,5e300]), np.array([1e300,1.,1e-300]))
    ])
    worst=0.; checked=0
    with mp.workdps(750):
        for b,a,w in cases:
            for metric in ('euclidean','width-weighted'):
                bb=list(map(lambda x:mp.mpf(float(x)),b)); aa=list(map(lambda x:mp.mpf(float(x)),a))
                ww=[mp.mpf(1)]*len(w) if metric=='euclidean' else list(map(lambda x:mp.mpf(float(x)),w))
                q=[x/y for x,y in zip(aa,ww)]
                t=mp.fsum(x*y for x,y in zip(bb,aa))/mp.fsum(x*y for x,y in zip(aa,q))
                ref=[x-t*y for x,y in zip(bb,q)]
                actual=C.project_tangent(b,a,w,metric)
                scale=max([abs(x) for x in bb]+[abs(x) for x in ref])
                err=float(max(abs(mp.mpf(float(x))-y) for x,y in zip(actual,ref))/scale) if scale else 0.
                need(err<4e-15, 'projection differs from independent 750-digit metric minimizer')
                worst=max(worst,err); checked+=1
    z=np.zeros(2); b=np.array([3.,-4.])
    for metric in ('euclidean','width-weighted'):
        p=C.project_tangent(b,z,[.2,.8],metric)
        need(np.array_equal(p,b) and not np.shares_memory(p,b), 'zero identity/copy failure')
    try:
        C.project_tangent([0.,1e308],[1e-308,1.],[1e-308,1e308],'width-weighted')
    except ValueError:
        overflow_rejected=True
    else:
        overflow_rejected=False
    need(overflow_rejected,'unrepresentable output not rejected')
    return {'metric_cases':checked,'max_normwise_error':worst,'subnormal_nonzero_normal_tested':True,'unrepresentable_output_rejected':True}

def historical_ast():
    src=RUN/'research/artifacts/proof-audit-round9-20260923/before/scripts/_gapn2_second_variation_probe.py'
    tree=ast.parse(src.read_text())
    nodes=[x for x in ast.walk(tree) if isinstance(x,ast.AugAssign) and isinstance(x.target,ast.Name) and x.target.id=='b' and 'fblock' in ast.unparse(x)]
    need(len(nodes)==2 and ast.dump(nodes[0],include_attributes=False)==ast.dump(nodes[1],include_attributes=False),'different P1/P2 AST')
    rows=[]
    for n,R,mode in [(2,4.,'sup')]:
        rc,z,blocks,_=C.build_case(n,R,mode)
        widths=np.array([x[0] for x in blocks]); edges=np.r_[0.,np.cumsum(widths)]
        roots=C.checked_roots(blocks,n+1); grid=np.linspace(0,1,4001); dx=grid[1]-grid[0]
        f=roots[n-1]**2*C.eigfun(blocks,roots[n-1],grid)**2-roots[n]**2*C.eigfun(blocks,roots[n],grid)**2
        assignments=[x for x in ast.walk(tree) if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('favg','fblock') for t in x.targets)]
        scope={'np':np,'f':f,'GRID':grid,'DX':dx,'xs':edges,'nb':len(blocks),'widths':widths,'b':np.array([1.,0.,0.,0.,0.])}
        exec(compile(ast.Module(body=assignments+[nodes[0]],type_ignores=[]),str(src),'exec'),scope)
        b=scope['b']
        t=C.HighPrecisionTangent(blocks,n,70)
        old=float(t.direct_residual(b)); repaired=C.project_tangent([1,0,0,0,0],t.A); new=float(t.direct_residual(repaired))
        def fh(x,i):
            return b[i]*(roots[n-1]**2*C.eigfun(blocks,roots[n-1],[x])[0]**2-roots[n]**2*C.eigfun(blocks,roots[n],[x])[0]**2)
        separate=sum(quad(lambda x:fh(x,i),l,r,epsabs=1e-12,epsrel=1e-12)[0] for i,(l,r) in enumerate(zip(edges[:-1],edges[1:])))
        need(abs(old)>1 and abs(new)<1e-13 and abs(old-separate)<1e-12,'source first variation control failed')
        rows.append({'legacy_average_dot':float(b@scope['fblock']),'legacy_direct_mp':old,'legacy_direct_scipy':separate,'repaired_direct_mp':new,'actual_old_integrals_error':float(max(abs(scope['favg']-t.A)))})
    with mp.workdps(80):
        pi=mp.pi
        f=lambda x:2*pi*pi*mp.sin(pi*x)**2-8*pi*pi*mp.sin(2*pi*x)**2
        a=[mp.quad(f,[0,mp.mpf(1)/4]),mp.quad(f,[mp.mpf(1)/4,1])]
        exact=[-3*pi*pi/4-pi/2,-9*pi*pi/4+pi/2]
        direction=[-(9*pi-2)/(3*(3*pi+2)),mp.mpf(1)]
        direct=direction[0]*a[0]+direction[1]*a[1]
        need(max(abs(x-y) for x,y in zip(a,exact))<mp.mpf('1e-70'),'exact SL integral')
        need(abs(direct-(-3*pi*pi/2+pi/3))<mp.mpf('1e-70'),'exact SL derivative')
        return {'source_case':rows,'exact_counterexample_derivative':mp.nstr(direct,40)}

def normalization_pairings_q():
    case_rows=[]
    for name in ('n2R4SUP','n3R4SUP','n2R10SUP','n2R4INF'):
        data=json.loads((ROOT/'evidence'/(name+'.json')).read_text())
        blocks=data['blocks']; edges=np.array(data['edges']); roots=C.checked_roots(blocks,61)
        norm_errors=[]; pairing_errors=[]
        for k in (0,data['n']-1,data['n'],7,60):
            val=sum(c*quad(lambda x:C.eigfun(blocks,roots[k],[x])[0]**2,l,r,epsabs=1e-12,epsrel=1e-12,limit=200)[0] for (l,r),(_,c) in zip(zip(edges[:-1],edges[1:]),blocks))
            norm_errors.append(abs(val-1))
        p=C.SpectralProbe(blocks,61,64); coeff=np.array(data['P2'][0]['coefficients'])
        lam,cu,cw,diagonal=p.pairings(C.block_direction(coeff,edges))
        for k,l in ((data['n']-1,data['n']-1),(data['n']-1,data['n']),(data['n'],60)):
            integrals=[quad(lambda x:C.eigfun(blocks,roots[k],[x])[0]*C.eigfun(blocks,roots[l],[x])[0],a,b,epsabs=1e-12,epsrel=1e-12,limit=200)[0] for a,b in zip(edges[:-1],edges[1:])]
            unweighted=sum(h*v for h,v in zip(coeff,integrals)); weighted=sum(h*c*v for h,(_,c),v in zip(coeff,blocks,integrals))
            pairing_errors.extend((abs(cu[k,l]-unweighted),abs(cw[k,l]-weighted)))
        need(max(norm_errors)<2e-12 and max(pairing_errors)<2e-12,'normalization or pairing mismatch')
        lam,cu,cw,diag=p.pairings(C.block_direction([c for _,c in blocks],edges))
        scale_q=C.q_formula(lam,cu,cw,data['n'],diag)
        need(abs(scale_q-(lam[data['n']]-lam[data['n']-1]))<1e-10,'h=rho exact scaling failed')
        case_rows.append({'case':name,'weighted_norm_max_error':max(norm_errors),'independent_pairing_max_error':max(pairing_errors),'rho_scaling_Q_error':abs(scale_q-(lam[data['n']]-lam[data['n']-1]))})
    c=2.5; modes=9; p=C.SpectralProbe([(.37,c),(.63,c)],modes,64)
    lam,cu,cw,diag=p.pairings(lambda x:1.1+.8*np.cos(np.pi*x)-.35*np.cos(2*np.pi*x))
    exact=np.empty((modes,modes))
    for k in range(1,modes+1):
        for l in range(1,modes+1):
            exact[k-1,l-1]=(1.1*(k==l)+.4*((abs(k-l)==1)-(k+l==1))-.175*((abs(k-l)==2)-(k+l==2)))/c
    need(np.max(abs(cu-exact))<2e-14 and np.max(abs(cw-c*exact))<5e-14,'closed form mixed Fourier pairings')
    qchecks=[]
    for n in (1,2,3,modes-1):
        with mp.workdps(80):
            eig=[mp.pi**2*k*k/mp.mpf(c) for k in range(1,modes+1)]
            second=[]
            for k in (n-1,n):
                a=mp.mpf(float(exact[k,k]))
                second.append(2*eig[k]*a*a+mp.fsum(2*eig[k]**2*mp.mpf(float(exact[k,l]))**2/(eig[k]-eig[l]) for l in range(modes) if l!=k))
            ref=float((second[1]-second[0])/2)
        q=C.q_formula(lam,cu,cw,n,diag)
        poison=C.q_formula(lam,cu,np.ones_like(cw)*123.,n,diag)
        need(abs(q-ref)<2e-11 and poison==q,'second variation indexing/sign or weighted pairing leak')
        qchecks.append({'n':n,'Q':q,'independent_exact_pairing_sum':ref,'error':abs(q-ref),'weighted_argument_independent':True})
    return {'nonconstant_density':case_rows,'exact_Fourier_pairings_max_error':float(np.max(abs(cu-exact))),'Q_checks':qchecks}

def p3_independent():
    data=json.loads((ROOT/'evidence/n2R4SUP.json').read_text()); blocks=data['blocks']; edges=np.array(data['edges']); interior=edges[1:-1]
    roots=C.checked_roots(blocks,3); jump=np.diff([c for _,c in blocks]); probe=C.SpectralProbe(blocks,61,64)
    def f(x):
        return roots[1]**2*C.eigfun(blocks,roots[1],[x])[0]**2-roots[2]**2*C.eigfun(blocks,roots[2],[x])[0]**2
    rows=[]
    for row in data['P3']:
        d=np.array(row['displacement']); eta=row['half_width']; breaks=np.r_[interior-eta,interior+eta]
        x,w,knots=C.quadrature_rule(blocks,64,breaks)
        direction=np.sum((-jump*d/(2*eta))[:,None]*(abs(x[None,:]-interior[:,None])<eta),axis=0)
        need(all(any(k==v for k in knots) for v in breaks),'missing bump breakpoint')
        expected_mass=float(-jump@d); actual_mass=float(w@direction)
        need(abs(actual_mass-expected_mass)<2e-11,'fixed bump mass integration')
        fp=np.array([(f(a+1e-7)-f(a-1e-7))/(2e-7) for a in interior])
        accel=-.5*np.sum(jump*d*d*fp)
        need(abs(accel-row['half_interface_acceleration'])<2e-3,'P3 half acceleration sign/factor')
        actions=[]
        for step in (1e-4,1e-6,1e-7):
            action=-sum(j*(quad(f,a,a+step*di,epsabs=1e-18,epsrel=1e-11)[0]+quad(f,a,a-step*di,epsabs=1e-18,epsrel=1e-11)[0]) for a,j,di in zip(interior,jump,d))/(2*step*step)
            actions.append({'h':step,'half_second':action,'absolute_error':abs(action-row['half_interface_acceleration'])})
        need(actions[-1]['absolute_error']<.01 and actions[-1]['absolute_error']<actions[0]['absolute_error']/100,'independent fixed-test-function shape acceleration')
        rows.append({'t':row['t'],'bump_mass_error':abs(actual_mass-expected_mass),'spatial_difference_acceleration':float(accel),'recorded_acceleration':row['half_interface_acceleration'],'shape_action_half_second':actions})
    return rows

def invalid_controls():
    cases=[['0','4','sup'],['2','.99','sup'],['2','nan','sup'],['2','inf','sup'],['2','4','invalid'],['--modes','2'],['--quad-order','7'],['--quad-order','8.5'],['--dps','29'],['--fd-steps','0'],['--fd-steps','-1'],['--fd-steps','nan'],['--fd-steps','inf'],['--bump-width','0'],['--bump-width','nan'],['--metric','bad']]
    rows=[]
    for flags in ([],['-O']):
        for args in cases:
            p=subprocess.run([sys.executable,'-B',*flags,'scripts/_gapn2_second_variation_probe.py',*args],cwd=RUN,capture_output=True,text=True,timeout=20)
            need(p.returncode==2 and 'error:' in p.stderr and 'Traceback' not in p.stderr,'CLI rejection failed: '+repr((flags,args,p.returncode,p.stderr)))
            rows.append({'optimized':bool(flags),'args':args,'exit':p.returncode})
    for h in (1.,2.):
        try:C.fd_second([(1.,1.)],[1.],0,h=h)
        except ValueError:pass
        else:raise RuntimeError('nonpositive FD endpoint silently clamped')
    h=np.nextafter(1.,0.)
    # Validate a close-to-boundary positive path with an analytically known mode.
    # Root enumeration is not expected to handle every extreme contrast; test a moderate interior step.
    step=.7
    fd=C.fd_second([(1.,1.)],[1.],0,h=step,dps=70)[0]
    with mp.workdps(70):
        expected=2*mp.pi**2/(1-mp.mpf(step)**2)
        need(abs(fd-expected)<mp.mpf('1e-45'),'positive path FD changed by clamping')
    return {'cli_rejections':rows,'no_clamping_zero_negative_endpoints_rejected':True,'positive_path_h_0_7_matches_exact':True}

if __name__=='__main__':
    for name,fn in [('projection_extremes_mp_reference',projection_reference),('historical_AST_and_first_variation',historical_ast),('normalization_pairings_second_variation',normalization_pairings_q),('P3_breakpoints_and_acceleration',p3_independent),('invalid_controls_normal_and_optimized',invalid_controls)]:
        group(name,fn)
    (ROOT/'evidence/independent_checks.json').write_text(json.dumps(ROWS,indent=2))
    sys.exit(int(any(not x['passed'] for x in ROWS)))
